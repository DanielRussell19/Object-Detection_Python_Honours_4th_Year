
Content_Moderation_Project - v2 2021-04-08 5:55pm
==============================

This dataset was exported via roboflow.ai on April 8, 2021 at 4:55 PM GMT

It includes 105 images.
Hateful-Pepe are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


